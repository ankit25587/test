var simpleScopeApp = angular.module('simpleScope', []);

simpleScopeApp.controller('SimpleScopeController1', ['$scope', function($scope) {
        $scope.randomPeople = [
            'Swetha',
            'Janani',
            'Vitthal',
            'Navdeep',
            'Pradeep',
            'Jitu',
            'Shreya',
            'Nirali'
        ];

        this.person = 'Vitthal';
        $scope.person = 'Janani';

        this.randomPersonOnController = function() {
            this.person = $scope.randomPeople[Math.floor(Math.random() * 8)];
        };

        $scope.randomPersonOnScope = function() {
            $scope.person = $scope.randomPeople[Math.floor(Math.random() * 8)];
        };

    }]);

simpleScopeApp.controller('SimpleScopeController2', ['$scope', function($scope) {
    $scope.randomPeople = [
        'Jim',
        'John',
        'Emily',
        'Nina',
        'Adam',
        'Alan',
        'Olga',
        'Sarah'
    ];

    this.person = 'Emily';
    $scope.person = 'Sarah';

    this.randomPersonOnController = function() {
        this.person = $scope.randomPeople[Math.floor(Math.random() * 8)];
    };

    $scope.randomPersonOnScope = function() {
        $scope.person = $scope.randomPeople[Math.floor(Math.random() * 8)];
    };

}]);
