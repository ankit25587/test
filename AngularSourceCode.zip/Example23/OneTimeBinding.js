
angular.module('oneTimeBinding', [])
    .controller('BindingController', function($scope) {
        var counter = 0;
        var names = ['Scorpius', 'Albus', 'Rose', 'James'];
        $scope.clickMe = function(clickEvent) {
            $scope.name = names[counter % names.length];
            counter++;
        };
    });
