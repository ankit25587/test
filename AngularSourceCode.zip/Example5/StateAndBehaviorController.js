
angular.module('hello', [])
    .controller('HelloController', ['$scope', function($scope) {
        $scope.entity = 'World';

        $scope.randomEntities = [
            'Bellandur',
            'Oakland',
            'Universe',
            'Mars',
            'Human'
        ];

        $scope.generateRandomEntity = function() {
            $scope.entity = $scope.randomEntities[Math.floor(Math.random() * 5)];
        };
        $scope.generateSpecificEntity = function(person) {
            $scope.entity = person;
        };

        $scope.customPerson = '';
    }]);
