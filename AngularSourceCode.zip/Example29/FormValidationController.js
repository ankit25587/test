angular.module('bindingForm', [])
.controller('BindingFormController', ['$scope', function($scope) {
    $scope.master = {};

    $scope.update = function(client) {
        $scope.master = angular.copy($scope.client);
    };

    $scope.reset = function(form) {
        if (form) {
            form.$setPristine();
            form.$setUntouched();
        }
        $scope.client = angular.copy($scope.master);
    };
}]);
