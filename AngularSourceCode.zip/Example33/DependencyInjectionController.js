var diApp = angular.module('dependencyInjection', []);

diApp.controller('DiController1', function($scope, $http) {
     $scope.test = 'Works!';
});

diApp.controller('DiController2', function(scope, http) {
    scope.test = 'Does not work:-(';
});

diApp.controller('DiController3', ['$scope', '$http', function(scope, http) {
    scope.test = 'This also works!';
}]);

var DiController4 = function($scope, $http) {
    $scope.test = 'This works as well!';
};

DiController4['$inject'] = ['$scope', '$http'];

diApp.controller("DiController4", DiController4);
