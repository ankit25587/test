angular.module('domDirective', [])
.controller('DomDirectiveController', ['$scope', function($scope) {
    $scope.hogwartsHeadmasters = [
        'Phineas Nigellus Black (1800s)',
        'Dilys Derwent (1741-1768)',
        'Armando Dippet (1940)',
        'Everard (unknown)',
        'Dexter Fortescue (unknown)',
        'Albus Dumbledore (1970-1997)',
        'Dolores Umbridge (1996)',
        'Severus Snape (1997-1998)',
        'Minerva McGonagall (1998-)'
    ];
}])
.directive('hogwartsHeadmasters', function($interval) {
    function link(scope, element, attrs) {
        function updateHeadmaster() {
            element.text(scope.hogwartsHeadmasters[
                Math.ceil(Math.random() * scope.hogwartsHeadmasters.length)]);
        }

        var timeoutId = $interval(function() {
            updateHeadmaster();
        }, 2000);

        element.on('$destroy', function() {
            $interval.cancel(timeoutId);
        });
    }

    return {
        link: link
    };
});
