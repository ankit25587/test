angular.module('simpleForm', [])
.controller('SimpleFormController', ['$scope', function($scope) {
    $scope.master = {};

    $scope.choices = [
        {id : "1", name: "1+ bedrooms"},
        {id : "2", name: "2+ bedrooms"},
        {id : "3", name: "3+ bedrooms"}
    ];

    $scope.update = function(client) {
        $scope.master = angular.copy($scope.client);
    };

    $scope.reset = function() {
        $scope.client = angular.copy($scope.master);
    };

    $scope.reset();
}]);
