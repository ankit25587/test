angular.module('expression', [])
.controller('ExpressionController', function($scope) {
    var exprsList = $scope.exprsList = [];

    $scope.expr = '10*10 | currency';
    $scope.addExp = function(expr) {
        exprsList.push(expr);
    };
});
