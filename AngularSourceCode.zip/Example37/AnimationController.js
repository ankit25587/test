var animationApp = angular.module('animation', ["ngAnimate"]);

animationApp.controller('AnimationController', function($scope) {
    $scope.$watch('expand', function() {
        if ($scope.expand) {
            $scope.someClass = "";
        } else {
            $scope.someClass = "small";
        }
    });
});
